const db = require('../config/db');

// Add a question to an assessment or test
const addQuestion = async (req, res) => {
  const { assessment_id, test_id, question_text, option_1, option_2, option_3, option_4, correct_answer } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO Questions (assessment_id, test_id, question_text, option_1, option_2, option_3, option_4, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [assessment_id, test_id, question_text, option_1, option_2, option_3, option_4, correct_answer]
    );
    res.status(201).json({ message: 'Question added successfully', question_id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error adding question' });
  }
};

// Get all questions for an assessment or test
const getQuestions = async (req, res) => {
  const { assessment_id, test_id } = req.query;
  try {
    let query = 'SELECT * FROM Questions WHERE ';
    if (assessment_id) {
      query += 'assessment_id = ?';
      var params = [assessment_id];
    } else if (test_id) {
      query += 'test_id = ?';
      var params = [test_id];
    } else {
      return res.status(400).json({ error: 'Provide either assessment_id or test_id' });
    }
    const [questions] = await db.query(query, params);
    res.status(200).json(questions);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching questions' });
  }
};

// Update a question
const updateQuestion = async (req, res) => {
  const { id } = req.params;
  const { question_text, option_1, option_2, option_3, option_4, correct_answer } = req.body;
  try {
    await db.query(
      'UPDATE Questions SET question_text = ?, option_1 = ?, option_2 = ?, option_3 = ?, option_4 = ?, correct_answer = ? WHERE question_id = ?',
      [question_text, option_1, option_2, option_3, option_4, correct_answer, id]
    );
    res.status(200).json({ message: 'Question updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating question' });
  }
};

// Delete a question
const deleteQuestion = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM Questions WHERE question_id = ?', [id]);
    res.status(200).json({ message: 'Question deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting question' });
  }
};

module.exports = {
  addQuestion,
  getQuestions,
  updateQuestion,
  deleteQuestion,
};