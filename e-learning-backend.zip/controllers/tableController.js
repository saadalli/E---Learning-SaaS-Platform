const db = require('../config/db'); // Import your database connection


const createTables = async () => {
    try {
      // Users Table (already created by you)
      await db.query(`
        CREATE TABLE IF NOT EXISTS Users (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            phone VARCHAR(15),
            password VARCHAR(255) NOT NULL,
            birthday DATE,
            role ENUM('admin', 'staff', 'student') DEFAULT 'student',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );`
      );
  
      // Courses Table
      await db.query(`
        CREATE TABLE IF NOT EXISTS Courses (
            course_id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            created_by INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES Users(user_id) ON DELETE CASCADE
        );`
      );
  
      // Assessments Table
      await db.query(`
        CREATE TABLE IF NOT EXISTS Assessments (
            assessment_id INT AUTO_INCREMENT PRIMARY KEY,
            course_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE
        );`
      );
  
      // Tests Table
      await db.query(`
        CREATE TABLE IF NOT EXISTS Tests (
            test_id INT AUTO_INCREMENT PRIMARY KEY,
            course_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE
        );`
      );
  
      // Questions Table (for Assessments and Tests)
      await db.query(`
        CREATE TABLE IF NOT EXISTS Questions (
            question_id INT AUTO_INCREMENT PRIMARY KEY,
            assessment_id INT,
            test_id INT,
            question_text TEXT NOT NULL,
            option_1 VARCHAR(255),
            option_2 VARCHAR(255),
            option_3 VARCHAR(255),
            option_4 VARCHAR(255),
            correct_answer VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (assessment_id) REFERENCES Assessments(assessment_id) ON DELETE CASCADE,
            FOREIGN KEY (test_id) REFERENCES Tests(test_id) ON DELETE CASCADE
        );`
      );
  
      // UserProgress Table (for tracking progress in Assessments, Tests, and Attendance)
      await db.query(`
        CREATE TABLE IF NOT EXISTS UserProgress (
            progress_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            course_id INT NOT NULL,
            assessment_id INT,
            test_id INT,
            score INT,
            status ENUM('completed', 'in_progress', 'not_started') DEFAULT 'not_started',
            completed_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE,
            FOREIGN KEY (assessment_id) REFERENCES Assessments(assessment_id) ON DELETE CASCADE,
            FOREIGN KEY (test_id) REFERENCES Tests(test_id) ON DELETE CASCADE
        );`
      );
  
      // Attendance Table
      await db.query(`
        CREATE TABLE IF NOT EXISTS Attendance (
            attendance_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            course_id INT NOT NULL,
            date DATE NOT NULL,
            status ENUM('present', 'absent') DEFAULT 'absent',
            FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE
        );`
      );
  
      console.log("All tables have been created successfully!");
    } catch (error) {
      console.error('Error creating tables:', error);
    }
  };
  
  module.exports = { createTables };