const db = require("../config/db")
const bcrypt = require('bcryptjs');
require('dotenv').config();
const jwt = require('jsonwebtoken');
const { createTables } = require("./tableController");


const getAllUsers = async (req, res) => {
    try {
        const [records] = await db.query('SELECT * FROM user')
        if (!records) {
            return res.send(404).send({
                success: false,
                message: 'No user found',
            })
        }

        res.status(200).send({
            success: true,
            message: 'All User Fetched',
            users: records
        })

    } catch (error) {
        console.log(error)
        req.status(500).send({
            success: false,
            message: 'Server error in server',
            error
        })
    }
}

const signupUser = async (req, res) => {
    try {
        const { name, email, password, phone, birthday, role } = req.body;
        // Check if the 'user' table exists, if not, create it

        // Check if user already exists
        const [existingUser] = await db.query('SELECT * FROM Users WHERE email = ?', [email]);
        if (existingUser.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Email already registered'
            });
        }

        // Hash the password before storing it
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user
        await db.query('INSERT INTO Users (name, email, password,phone,birthday ,role) VALUES (?, ?, ?, ?,?,?)', [name, email, hashedPassword, phone, birthday, role || 'customer']);

        res.status(201).json({
            success: true,
            message: 'User registered successfully'
        });

    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: 'Server error in signup',
            error
        });
    }
};

// Login Controller (with JWT Token)
const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user exists
        const [user] = await db.query('SELECT * FROM Users WHERE email = ?', [email]);
        if (user.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user[0].password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Generate JWT token
        const token = jwt.sign(
            { id: user[0].user_id, email: user[0].email, role: user[0].role,phone: user[0].phone,birthday: user[0].birthday },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES }
        );

        res.status(200).json({
            success: true,
            message: 'Login successful',
            token,
            id: user[0].user_id,
            name: user[0].name,
            email: user[0].email,
            role: user[0].role

        });

    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: 'Server error in login',
            error
        });
    }
};


const getUserById = async (req, res) => {
    try {
        const userId = req.user.id; // Extract ID from token payload
        console.log("Decoded Token:", req.user);

        // Fetch user details from database
        const [user] = await db.query('SELECT user_id, name, email, role, phone, birthday FROM Users WHERE user_id = ?', [userId]);

        if (!user.length) {
            return res.status(404).json({
                success: false,
                message: 'User not found',
            });
        }

        res.status(200).json({
            success: true,
            message: 'User details fetched successfully',
            user: user[0],
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: 'Server error while fetching user details',
            error,
        });
    }
};
createTables()

module.exports = { getAllUsers, signupUser, loginUser, getUserById }