const db = require('../config/db');

// Create a new course
const createCourse = async (req, res) => {
  const { title, description, created_by } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO Courses (title, description, created_by) VALUES (?, ?, ?)',
      [title, description, created_by]
    );
    res.status(201).json({ message: 'Course created successfully', course_id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error creating course' });
    console.log(error)
  }
};

// Get all courses
const getAllCourses = async (req, res) => {
  try {
    const [courses] = await db.query('SELECT * FROM Courses');
    res.status(200).json(courses);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching courses' });
  }
};

// Get a single course by ID
const getCourseById = async (req, res) => {
  const { id } = req.params;
  try {
    const [course] = await db.query('SELECT * FROM Courses WHERE course_id = ?', [id]);
    if (course.length === 0) {
      return res.status(404).json({ error: 'Course not found' });
    }
    res.status(200).json(course[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching course' });
  }
};

// Update a course
const updateCourse = async (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;
  try {
    await db.query('UPDATE Courses SET title = ?, description = ? WHERE course_id = ?', [title, description, id]);
    res.status(200).json({ message: 'Course updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating course' });
  }
};

// Delete a course
const deleteCourse = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM Courses WHERE course_id = ?', [id]);
    res.status(200).json({ message: 'Course deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting course' });
  }
};

module.exports = {
  createCourse,
  getAllCourses,
  getCourseById,
  updateCourse,
  deleteCourse,
};