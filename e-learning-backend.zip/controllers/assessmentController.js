const db = require('../config/db');

// Create a new assessment
const createAssessment = async (req, res) => {
  const { course_id, title, description } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO Assessments (course_id, title, description) VALUES (?, ?, ?)',
      [course_id, title, description]
    );
    res.status(201).json({ message: 'Assessment created successfully', assessment_id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error creating assessment' });
  }
};

// Get all assessments for a course
const getAssessmentsByCourseId = async (req, res) => {
  const { course_id } = req.params;
  try {
    const [assessments] = await db.query('SELECT * FROM Assessments WHERE course_id = ?', [course_id]);
    res.status(200).json(assessments);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching assessments' });
  }
};

// Get a single assessment by ID
const getAssessmentById = async (req, res) => {
  const { id } = req.params;
  try {
    const [assessment] = await db.query('SELECT * FROM Assessments WHERE assessment_id = ?', [id]);
    if (assessment.length === 0) {
      return res.status(404).json({ error: 'Assessment not found' });
    }
    res.status(200).json(assessment[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching assessment' });
  }
};

// Update an assessment
const updateAssessment = async (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;
  try {
    await db.query('UPDATE Assessments SET title = ?, description = ? WHERE assessment_id = ?', [title, description, id]);
    res.status(200).json({ message: 'Assessment updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating assessment' });
  }
};

// Delete an assessment
const deleteAssessment = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM Assessments WHERE assessment_id = ?', [id]);
    res.status(200).json({ message: 'Assessment deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting assessment' });
  }
};

module.exports = {
  createAssessment,
  getAssessmentsByCourseId,
  getAssessmentById,
  updateAssessment,
  deleteAssessment,
};