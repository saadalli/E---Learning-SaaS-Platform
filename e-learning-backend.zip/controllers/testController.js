const db = require('../config/db');

// Create a new test
const createTest = async (req, res) => {
  const { course_id, title, description } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO Tests (course_id, title, description) VALUES (?, ?, ?)',
      [course_id, title, description]
    );
    res.status(201).json({ message: 'Test created successfully', test_id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error creating test' });
  }
};

// Get all tests for a course
const getTestsByCourseId = async (req, res) => {
  const { course_id } = req.params;
  try {
    const [tests] = await db.query('SELECT * FROM Tests WHERE course_id = ?', [course_id]);
    res.status(200).json(tests);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching tests' });
  }
};

// Get a single test by ID
const getTestById = async (req, res) => {
  const { id } = req.params;
  try {
    const [test] = await db.query('SELECT * FROM Tests WHERE test_id = ?', [id]);
    if (test.length === 0) {
      return res.status(404).json({ error: 'Test not found' });
    }
    res.status(200).json(test[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching test' });
  }
};

// Update a test
const updateTest = async (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;
  try {
    await db.query('UPDATE Tests SET title = ?, description = ? WHERE test_id = ?', [title, description, id]);
    res.status(200).json({ message: 'Test updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating test' });
  }
};

// Delete a test
const deleteTest = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM Tests WHERE test_id = ?', [id]);
    res.status(200).json({ message: 'Test deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting test' });
  }
};

module.exports = {
  createTest,
  getTestsByCourseId,
  getTestById,
  updateTest,
  deleteTest,
};