const db = require('../config/db');

// Track user progress for an assessment or test
const trackProgress = async (req, res) => {
  const { user_id, course_id, assessment_id, test_id, score, status } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO UserProgress (user_id, course_id, assessment_id, test_id, score, status) VALUES (?, ?, ?, ?, ?, ?)',
      [user_id, course_id, assessment_id, test_id, score, status]
    );
    res.status(201).json({ message: 'Progress tracked successfully', progress_id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error tracking progress' });
  }
};

// Get user progress for a course
const getUserProgressByCourse = async (req, res) => {
  const { user_id, course_id } = req.params;
  try {
    const [progress] = await db.query(
      'SELECT * FROM UserProgress WHERE user_id = ? AND course_id = ?',
      [user_id, course_id]
    );
    res.status(200).json(progress);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching user progress' });
  }
};

// Update user progress
const updateProgress = async (req, res) => {
  const { id } = req.params;
  const { score, status } = req.body;
  try {
    await db.query(
      'UPDATE UserProgress SET score = ?, status = ? WHERE progress_id = ?',
      [score, status, id]
    );
    res.status(200).json({ message: 'Progress updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating progress' });
  }
};

// Delete user progress
const deleteProgress = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM UserProgress WHERE progress_id = ?', [id]);
    res.status(200).json({ message: 'Progress deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting progress' });
  }
};

module.exports = {
  trackProgress,
  getUserProgressByCourse,
  updateProgress,
  deleteProgress,
};