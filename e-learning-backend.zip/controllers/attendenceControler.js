const db = require('../config/db');

// Mark attendance for a user
const markAttendance = async (req, res) => {
  const { user_id, course_id, date, status } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO Attendance (user_id, course_id, date, status) VALUES (?, ?, ?, ?)',
      [user_id, course_id, date, status]
    );
    res.status(201).json({ message: 'Attendance marked successfully', attendance_id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error marking attendance' });
  }
};

// Get attendance for a user in a course
const getAttendanceByUserAndCourse = async (req, res) => {
  const { user_id, course_id } = req.params;
  try {
    const [attendance] = await db.query(
      'SELECT * FROM Attendance WHERE user_id = ? AND course_id = ?',
      [user_id, course_id]
    );
    res.status(200).json(attendance);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching attendance' });
  }
};

// Update attendance
const updateAttendance = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  try {
    await db.query(
      'UPDATE Attendance SET status = ? WHERE attendance_id = ?',
      [status, id]
    );
    res.status(200).json({ message: 'Attendance updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating attendance' });
  }
};

// Delete attendance
const deleteAttendance = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM Attendance WHERE attendance_id = ?', [id]);
    res.status(200).json({ message: 'Attendance deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting attendance' });
  }
};

module.exports = {
  markAttendance,
  getAttendanceByUserAndCourse,
  updateAttendance,
  deleteAttendance,
};