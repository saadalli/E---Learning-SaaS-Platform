const express = require('express');
const { createCourse, getAllCourses, getCourseById, updateCourse, deleteCourse } = require('../controllers/courseController');
const { createAssessment, getAssessmentsByCourseId, getAssessmentById, updateAssessment, deleteAssessment } = require('../controllers/assessmentController');
const { createTest, getTestsByCourseId, getTestById, updateTest, deleteTest } = require('../controllers/testController');
const { addQuestion, getQuestions, updateQuestion, deleteQuestion } = require('../controllers/questionController');
const { trackProgress, getUserProgressByCourse, updateProgress, deleteProgress } = require('../controllers/userProgressController');
const { markAttendance, getAttendanceByUserAndCourse, updateAttendance, deleteAttendance } = require('../controllers/attendenceControler');
const router = express.Router();

// Create a new course
router.post('/courses', createCourse);

// Get all courses
router.get('/courses', getAllCourses);

// Get a single course by ID
router.get('/courses/:id', getCourseById);

// Update a course
router.put('/courses/:id', updateCourse);

// Delete a course
router.delete('/courses/:id', deleteCourse);

// Create a new assessment
router.post('/assessments', createAssessment);

// Get all assessments for a course
router.get('/courses/:course_id/assessments', getAssessmentsByCourseId);

// Get a single assessment by ID
router.get('/assessments/:id', getAssessmentById);

// Update an assessment
router.put('/assessments/:id', updateAssessment);

// Delete an assessment
router.delete('/assessments/:id', deleteAssessment);


// Create a new test
router.post('/tests', createTest);

// Get all tests for a course
router.get('/courses/:course_id/tests', getTestsByCourseId);

// Get a single test by ID
router.get('/tests/:id', getTestById);

// Update a test
router.put('/tests/:id', updateTest);

// Delete a test
router.delete('/tests/:id', deleteTest);


// Add a question to an assessment or test
router.post('/questions', addQuestion);

// Get all questions for an assessment or test
router.get('/questions', getQuestions);

// Update a question
router.put('/questions/:id', updateQuestion);

// Delete a question
router.delete('/questions/:id', deleteQuestion);


// Track user progress for an assessment or test
router.post('/progress', trackProgress);

// Get user progress for a course
router.get('/users/:user_id/courses/:course_id/progress', getUserProgressByCourse);

// Update user progress
router.put('/progress/:id', updateProgress);

// Delete user progress
router.delete('/progress/:id', deleteProgress);


// Mark attendance for a user
router.post('/attendance', markAttendance);

// Get attendance for a user in a course
router.get('/users/:user_id/courses/:course_id/attendance', getAttendanceByUserAndCourse);

// Update attendance
router.put('/attendance/:id', updateAttendance);

// Delete attendance
router.delete('/attendance/:id', deleteAttendance);


module.exports = router;