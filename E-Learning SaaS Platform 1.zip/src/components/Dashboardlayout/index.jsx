'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { MdOutlineAssignment, MdOutlineDashboard, MdOutlineInbox } from "react-icons/md";
import { RiArrowLeftSLine, RiArrowRightSLine, RiShareCircleFill } from "react-icons/ri";
import { FiEdit, FiFilePlus } from "react-icons/fi";
import { IoMdClose } from "react-icons/io";
import { PiStarFourFill } from "react-icons/pi";
import { FaBars, FaBell } from 'react-icons/fa';
import { BsGearFill } from "react-icons/bs";
import { CiSearch } from "react-icons/ci";
import { motion, AnimatePresence } from 'framer-motion';
const DashboardLayout = ({ children, pageTitle }) => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const pathname = usePathname();
    const [isNotificationsOpen, setNotificationsOpen] = useState(false);
    const [isProfileOpen, setProfileOpen] = useState(false);
    // Function to toggle sidebar
    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };
    const router = useRouter();

    useEffect(() => {
        const token = localStorage.getItem('token');
        const user = JSON.parse(localStorage.getItem('user'));

        if (!token || user?.role !== 'admin') {
            router.push('/'); // Redirect to login if not authenticated or not an admin
        }
    }, [router]);
    // Dummy notifications data
    const notifications = [
        { id: 1, text: 'New booking received', time: '2 hours ago' },
        { id: 2, text: 'Session scheduled', time: '5 hours ago' },
        { id: 3, text: 'Tournament update', time: '1 day ago' },
    ];
    // Function to toggle notifications dropdown
    const toggleNotifications = () => {
        setNotificationsOpen(!isNotificationsOpen);
        setProfileOpen(false); // Close profile dropdown if open
    };

    // Function to toggle profile dropdown
    const toggleProfile = () => {
        setProfileOpen(!isProfileOpen);
        setNotificationsOpen(false); // Close notifications dropdown if open
    };
    // Effect to handle screen resize
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 1024) {
                setSidebarOpen(false); // Close sidebar on small screens
            } else {
                setSidebarOpen(true); // Open sidebar on larger screens
            }
        };

        // Add event listener for window resize
        window.addEventListener('resize', handleResize);

        // Initial check on component mount
        handleResize();

        // Cleanup event listener on component unmount
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('user')
        localStorage.removeItem('token')
        router.push('/')
    }
    return (
        <div className={`flex min-h-screen bg-white  p-8 ${isSidebarOpen ? "" : ""} `}>
            {/* Sidebar */}
            <div
                className={`   min-h-screen h-full text-black ${isSidebarOpen ? 'w-64' : 'w-16'} transition-width duration-300 relative`}
                style={{
                    position: window.innerWidth < 768 ? 'absolute' : 'relative', // Absolute position on small screens
                    zIndex: 50, // Ensure sidebar is above other content
                    height: '100vh', // Full height
                    left: isSidebarOpen ? '0px' : '0px', // Hide sidebar when closed on small screens
                }}
            >
                {/* <div className="p-4 absolute top-1 -right-10">
                    <button onClick={toggleSidebar} className="text-black focus:outline-none">
                        {isSidebarOpen ? (
                            <span className='h-10 w-10 bg-grad rounded-full text-black flex justify-center items-center'>
                                <IoMdClose size={20} />
                            </span>
                        ) : (
                            <span className='h-10 w-10 bg-grad rounded-full text-black flex justify-center items-center'>
                                <FaBars size={20} />
                            </span>
                        )}
                    </button>
                </div> */}
                <div onClick={toggleSidebar} className={`flex h-20 items-center ${isSidebarOpen ? "" : "p-4 "} gap-2 `}>
                    <span className='h-10 w-10 rounded-full flex justify-center items-center bg-blue-800'>
                        <PiStarFourFill className='text-white' size={18} />
                    </span>
                    <h1 className={`font-extrabold text-blue-800 textlg ${isSidebarOpen ? "" : "hidden"} `}>MINDLEAP</h1>
                </div>
                <nav>
                    <ul>
                        <li className={`p-4 mb-2 ${pathname === '/' ? "text-white rounded-xl bg-black font-bold" : "text-black"}`}>
                            <Link
                                href="/"
                                className={`flex items-center `}
                            >
                                <div className={`flex items-center ${isSidebarOpen ? 'gap-2' : "gap-0"} leading-none`}>
                                    <MdOutlineDashboard className='' size={20} />
                                    {isSidebarOpen && "Overview"} {/* Show text only when sidebar is open */}
                                </div>
                            </Link>
                        </li>


                        <li className={`p-4 mb-2 ${pathname === '/assignments' ? "text-white rounded-xl bg-black font-bold" : "text-black"}`}>
                            <Link
                                href="/assignments"
                                className={`flex items-center `}
                            >
                                <div className={`flex items-center ${isSidebarOpen ? 'gap-2' : "gap-0"} leading-none`}>
                                    <MdOutlineAssignment size={20} />
                                    {isSidebarOpen && "Assignments"} {/* Show text only when sidebar is open */}
                                </div>
                            </Link>
                        </li>
                        <li className={`p-4 mb-2 ${pathname === '/reports' ? "text-white rounded-xl bg-black font-bold" : "text-black"}`}>
                            <Link
                                href="/reports"
                                className={`flex items-center `}
                            >
                                <div className={`flex items-center ${isSidebarOpen ? 'gap-2' : "gap-0"} leading-none`}>
                                    <RiShareCircleFill size={20} />
                                    {isSidebarOpen && "Reports"} {/* Show text only when sidebar is open */}
                                </div>
                            </Link>
                        </li>
                        <li className={`p-4 mb-2 ${pathname === '/file' ? "text-white rounded-xl bg-black font-bold" : "text-black"}`}>
                            <Link
                                href="/file"
                                className={`flex items-center `}
                            >
                                <div className={`flex items-center ${isSidebarOpen ? 'gap-2' : "gap-0"} leading-none`}>
                                    <FiFilePlus size={20} />
                                    {isSidebarOpen && "File Storage"} {/* Show text only when sidebar is open */}
                                </div>
                            </Link>
                        </li>
                        <li className={`p-4 mb-2 ${pathname === '/inbox' ? "text-white rounded-xl bg-black font-bold" : "text-black"}`}>
                            <Link
                                href="/inbox"
                                className={`flex items-center `}
                            >
                                <div className={`flex items-center ${isSidebarOpen ? 'gap-2' : "gap-0"} leading-none`}>
                                    <MdOutlineInbox size={20} />
                                    {isSidebarOpen && "Inbox"} {/* Show text only when sidebar is open */}
                                </div>
                            </Link>
                        </li>
                        <li className={`p-4 mb-2 ${pathname === '/setting' ? "text-white rounded-xl bg-black font-bold" : "text-black"}`}>
                            <Link
                                href="/setting"
                                className={`flex items-center `}
                            >
                                <div className={`flex items-center ${isSidebarOpen ? 'gap-2' : "gap-0"} leading-none`}>
                                    <BsGearFill size={20} />
                                    {isSidebarOpen && "Setting"} {/* Show text only when sidebar is open */}
                                </div>
                            </Link>
                        </li>

                    </ul>
                </nav>
            </div>

            {/* Main Content */}
            <div className={`${(window.innerWidth < 768 && !isSidebarOpen) && 'pl-16'}  flex-1 overflow-x-hidden relative`}>
                <div className='h-20 pl-10 pr-4 flex justify-between items-center'>
                    <div>
                        <h1 className='text-black font-bold text-xl'>Hello Admin</h1>
                        <p className='text-xs text-gray-400 '>Let's learn something new today</p>
                    </div>
                    <div className='flex items-center gap-4 '>
                        <div className='h-10 p-3 flex items-center text-black rounded-lg border border-gray-200'>
                            <input type="text" placeholder='search from courses...' className='flex-1' />
                            <CiSearch />
                        </div>
                        {/* Notifications Dropdown */}
                        <div className="relative">
                            <button onClick={toggleNotifications} className="text-black focus:outline-none h-10 w-10 flex justify-center items-center border border-gray-200 rounded-lg">
                                <FaBell size={24} />
                            </button>
                            <AnimatePresence>
                                {isNotificationsOpen && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        transition={{ duration: 0.3 }}
                                        className="absolute -right-10 mt-2 w-64 z-50 bg-white rounded-lg shadow-lg"
                                    >
                                        <div className="p-4">
                                            <h3 className="font-bold text-black">Notifications</h3>
                                            <ul className="mt-2 space-y-2">
                                                {notifications.map((notification) => (
                                                    <li key={notification.id} className="text-sm text-gray-700">
                                                        <p>{notification.text}</p>
                                                        <p className="text-xs text-gray-500">{notification.time}</p>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>


                    </div>

                </div>
                <div className='p-4'>

                    {children}
                </div>
            </div>

            <div className='w-64 hidden  text-black sm:flex flex-col  items-center p-4'>
                <div className='flex justify-between items-center w-full text-black pt-2 border border-gray-200'>
                    <h1 className='text-lg font-bold '>Profile</h1>
                    <FiEdit size={24} />
                </div>

                <div className='h-40 w-40 rounded-full p-6'>
                    <img src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSY868zut2XeJUSYXCOY1DiUNPTa8qm1I8IUeDNZNdbRvTey3ubJhnDzyLGkLP-4FA2p1E1O6r01aBjBXESI2Hmzg" className='rounded-full' alt="profile" />

                </div>

                <h1 className='text-xl font-bold '>Habib Ahmed</h1>
                <p className='mt-2'>Software Engineer</p>

                <div className='w-full flex justify-between items-center mt-6'>
                    <RiArrowLeftSLine />
                    <h1 className=''>Febraruary 2025</h1>
                    <RiArrowRightSLine />

                </div>

                <div className='flex justify-between items-center w-full text-gray-400 mt-2'>
                    <div className='h-20  flex flex-col justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>M</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>24</p>
                    </div>
                    <div className='h-20 bg-black flex flex-col items-center justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>T</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center text-white bg-blue-500'>25</p>
                    </div>
                    <div className='h-20  flex flex-col justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>W</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>26</p>
                    </div>
                    <div className='h-20  flex flex-col justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>T</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>27</p>
                    </div>
                    <div className='h-20  flex flex-col justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>F</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>28</p>
                    </div>
                    <div className='h-20  flex flex-col justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>S</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>29</p>
                    </div>
                    <div className='h-20  flex flex-col justify-between p-1 rounded-full'>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>S</p>
                        <p className='w-6 h-6 rounded-full flex justify-center items-center'>30</p>
                    </div>

                </div>

                <h1 className='text-lg font-bold text-black my-7 text-start'>To Do List</h1>
                <div>
                    <div className='flex gap-2'>
                        <input type="checkbox" className='h-5 w-5 rounded-lg' />
                        <div>
                            <h1 className='font-semibold text-[14px] leading-none text-gray-600'>Developing Restaurant App</h1>
                            <h1>
                                <span className='text-xs text-gray-500'>Programming</span>
                                <span className='text-xs text-red-500'> 08:00 PM</span>
                            </h1>
                        </div>



                    </div>
                    <div className='pl-6 mt-4'>
                        <div className='flex gap-2 mb-2'>
                            <input type="checkbox" name="" id="" className='h-5 w-5 rounded-lg' />
                            <h1 className='font-semibold text-[14px] leading-none text-gray-600'>Integrate API</h1>
                        </div>
                        <div className='flex gap-2 '>
                            <input type="checkbox" name="" id="" className='h-5 w-5 rounded-lg' />
                            <h1 className='font-semibold text-[14px] leading-none text-gray-600'>Slicong Home Screen</h1>
                        </div>

                    </div>
                    <div className='flex gap-2 mt-4'>
                        <input type="checkbox" className='h-5 w-5 rounded-lg' />
                        <div>
                            <h1 className='font-semibold text-[14px] leading-none text-gray-600'>Research Objective User</h1>
                            <h1>
                                <span className='text-xs text-gray-500'>Product Design </span>
                                <span className='text-xs text-red-500'> 04:40 PM</span>
                            </h1>
                        </div>



                    </div>
                    <div className='flex gap-2 mt-4'>
                        <input type="checkbox" className='h-5 w-5 rounded-lg' />
                        <div>
                            <h1 className='font-semibold text-[14px] leading-none text-gray-600 line-through'>Report Analysis P2P Business</h1>
                            <h1>
                                <span className='text-xs text-gray-500'>Business</span>
                                <span className='text-xs text-red-500'> 04:50 PM</span>
                            </h1>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    );
};

export default DashboardLayout;