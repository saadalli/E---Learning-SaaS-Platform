import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { RadialBarChart, RadialBar } from "recharts";

const data = [
  { name: "Jan", Study: 30, Exams: 35 },
  { name: "Feb", Study: 20, Exams: 25 },
  { name: "Mar", Study: 55, Exams: 32 },
  { name: "Apr", Study: 35, Exams: 25 },
  { name: "May", Study: 15, Exams: 10 },
];

const performanceData = [{ value: 30 }];

export default function Charts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-6">
      {/* Hours Spent Chart */}
      <div className="bg-white p-6 shadow-md rounded-xl text-black">
        <h2 className="text-lg font-semibold mb-4">Hours Spent</h2>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={data} barGap={10}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="Study" stackId="a" fill="blue" />
            <Bar dataKey="Exams" stackId="a" fill="#fceee4" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Performance Chart */}
      <div className="bg-white p-6 shadow-md rounded-xl text-black">
        <h2 className="text-lg font-semibold mb-4">Performance</h2>
        <ResponsiveContainer width="100%" height={250}>
  <RadialBarChart 
    cx="50%" 
    cy="50%" 
    innerRadius="80%" 
    outerRadius="100%" 
    startAngle={135}  // Starts from 135°
    endAngle={-135}   // Ends at -135° (75% of a circle)
    data={performanceData}
  >
    <RadialBar 
      minAngle={15} 
      dataKey="value" 
      fill="blue" 
      background 
      strokeWidth={6} // Reduced stroke width
    />
  </RadialBarChart>
</ResponsiveContainer>

        <p className="text-center mt-2 font-semibold text-gray-500">Your Point: <span className="text-xl text-black">8.966</span></p>
      </div>
    </div>
  );
}
