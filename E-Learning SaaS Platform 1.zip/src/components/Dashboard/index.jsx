'use client'
import React from 'react'
import Charts from './Charts';
import Leaderboard from './Table';

const Dashboard = () => {
    const courses = [
        {
            title: "Basic: HTML and CSS",
            icon: "💻",
            bgColor: "bg-purple-100",
            textColor: "text-purple-600",
        },
        {
            title: "Branding Design",
            icon: "🏗️",
            bgColor: "bg-yellow-100",
            textColor: "text-yellow-600",
        },
        {
            title: "Motion Design",
            icon: "📈",
            bgColor: "bg-green-100",
            textColor: "text-green-600",
        },
    ];
    return (
        <div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 p-4">
                {courses.map((course, index) => (
                    <div
                        key={index}
                        className={`p-6 rounded-xl shadow-md ${course.bgColor} flex flex-col justify-between gap-4`}
                    >
                        <div className={`text-3xl ${course.textColor}`}>{course.icon}</div>
                        <h3 className=" font-semibold text-gray-900">{course.title}</h3>
                        <div className="flex justify-between text-gray-500 rounded-lg bg-white text-sm p-3">
                            <span className="flex items-center gap-1">📖 24</span>
                            <span className="flex items-center gap-1">📝 8</span>
                            <span className="flex items-center gap-1">👥 99</span>
                        </div>
                    </div>
                ))}
            </div>

            <Charts/>
            <Leaderboard/>
        </div>
    )
}

export default Dashboard
