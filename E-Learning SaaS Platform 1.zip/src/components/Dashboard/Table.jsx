import React from "react";

const leaderboardData = [
  {
    rank: 1,
    name: "Charlie Rawal",
    image: "https://randomuser.me/api/portraits/men/1.jpg",
    course: 53,
    hour: 250,
    point: "13.450",
    trend: "up",
  },
  {
    rank: 2,
    name: "Ariana Agarwal",
    image: "https://randomuser.me/api/portraits/women/2.jpg",
    course: 88,
    hour: 212,
    point: "10.333",
    trend: "down",
  },
];

export default function Leaderboard() {
  return (
    <div className="p-6 bg-white shadow-md rounded-xl text-black">
      <h2 className="text-xl font-semibold mb-4">Leader Board</h2>
      <table className="w-full text-left">
        <thead>
          <tr className="border-b text-gray-500">
            <th className="p-3">RANK</th>
            <th className="p-3">NAME</th>
            <th className="p-3">COURSE</th>
            <th className="p-3">HOUR</th>
            <th className="p-3">POINT</th>
          </tr>
        </thead>
        <tbody>
  {leaderboardData.map((user, index) => (
    <tr key={index} className="border-b">
      {/* Rank Column */}
      <td className="p-3">
  <div className="flex items-center space-x-2">
    <span className="w-6 h-6 flex items-center justify-center rounded bg-gray-100 font-semibold">
      {user.rank}
    </span>
    {user.trend === "up" ? (
      <span className="text-green-500">▲</span>
    ) : (
      <span className="text-red-500">▼</span>
    )}
  </div>
</td>


      {/* Name Column */}
      <td className="p-3 flex items-center space-x-3">
  <img src={user.image} alt={user.name} className="w-8 h-8 rounded-full" />
  <span className="font-semibold">{user.name}</span>
</td>


      {/* Course, Hour, Point Columns */}
      <td className="p-3">{user.course}</td>
      <td className="p-3">{user.hour}</td>
      <td className="p-3 text-blue-500 font-semibold">{Number(user.point)}</td>
    </tr>
  ))}
</tbody>

      </table>
    </div>
  );
}
