import DashboardLayout from '@/components/Dashboardlayout'
import React from 'react'

const AssignmentPage = () => {
  return (
    <DashboardLayout>
      Assignment page content
    </DashboardLayout>
  )
}

export default AssignmentPage
