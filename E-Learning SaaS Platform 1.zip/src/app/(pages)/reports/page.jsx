import DashboardLayout from '@/components/Dashboardlayout'
import React from 'react'

const ReportPage = () => {
  return (
    <DashboardLayout>
      Report page content
    </DashboardLayout>
  )
}

export default ReportPage
