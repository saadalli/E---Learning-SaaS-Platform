import DashboardLayout from '@/components/Dashboardlayout'
import React from 'react'

const SettingPage = () => {
  return (
    <DashboardLayout>
      Setting Page Content
    </DashboardLayout>
  )
}

export default SettingPage
