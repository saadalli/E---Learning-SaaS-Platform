import DashboardLayout from '@/components/Dashboardlayout'
import React from 'react'

const InboxPage = () => {
  return (
    <DashboardLayout>
      inbox page
    </DashboardLayout>
  )
}

export default InboxPage
