import DashboardLayout from '@/components/Dashboardlayout'
import React from 'react'

const FilePage = () => {
  return (
    <DashboardLayout>
      File Storage
    </DashboardLayout>
  )
}

export default FilePage
