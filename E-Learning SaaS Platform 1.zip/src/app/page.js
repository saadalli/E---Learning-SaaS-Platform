import Dashboard from "@/components/Dashboard";
import DashboardLayout from "@/components/Dashboardlayout";
import Image from "next/image";

export default function Home() {
  return (
    <>
    <DashboardLayout>
      <Dashboard/>
    </DashboardLayout>
    </>
  );
}
